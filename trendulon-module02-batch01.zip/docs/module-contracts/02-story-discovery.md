# Module 02 — Story Discovery — Contract

Status: **Batch 1 — data models + interfaces only. No live integrations, no UI, no scoring calculation.**

## Purpose
Find candidate stories, preserve their provenance, and rank them into a
provisional Top 5 for the editor. Per TECH SPEC Section 10: mostly
plumbing (RSS/news-API pulls), not an LLM task — Claude's only role here
is de-duplicating near-identical stories across sources (not built yet).

## Responsibilities
- Own and write the `stories` table on insert (`status: "discovered"` only).
- Own and write `story_sources` (provenance for every candidate).
- Own and write `discovery_runs` (so Module 01 can show run health).
- Compute and write a **provisional Discovery Score** used only to select
  the Top 5 candidates shown to the editor.

## Non-responsibilities
- **Does not** compute or write the Core Section 5 Trendulon Fit Score
  (`fit_score`, `reasons[]`, `recommended_priority`) — that is Module 03's
  exclusively.
- **Does not** write `evidence_confidence` — that is Module 04's.
- **Does not** call live `web_search` per candidate (TECH SPEC honest
  flag, Section 10) — reserved for Module 04.
- **Does not** implement a real search provider, the scoring calculation,
  or any UI in this batch.
- **Does not** modify `TRENDULON_CORE.md`, `TRENDULON_TECH_SPEC.md`, or
  any Module 01 file.

## Discovery Score vs. Fit Score — the distinction this batch enforces
| | Discovery Score | Fit Score |
|---|---|---|
| Owner | Module 02 | Module 03 |
| Purpose | Provisional ranking of raw candidates into a Top 5 | Authoritative Core Section 5 editorial score |
| Type | `DiscoveryScore` (`discovery-score.ts`) | `FitScoreRef` (`downstream-refs.ts`) |
| Field on `Story` | `discovery_score?: number` | `fit?: FitScoreRef` |
| Written via | `StoryDiscoveryRepository.saveDiscoveryScore` | (no method on this repository — Module 03 owns its own) |
| Config | `discovery-scoring-weights.ts` | Module 03's own config (not in this codebase yet) |

`StoryDiscoveryInput` (Module 02's insert shape) has no `fit`,
`evidence_confidence`, or `priority` fields at the type level — this is a
compile-time guarantee, not just a convention, that Module 02 code cannot
write those columns. `story-validation.ts` adds a runtime guard on top of
that for anything constructed outside the type system.

## Inputs
- Schedule trigger (e.g. every 2 hours) or manual trigger from the
  Dashboard's "Find Today's Stories" action (`FindStoriesAction.tsx`,
  currently a client-side placeholder in Module 01).
- Raw results from one or more `SearchProvider` implementations
  (none implemented yet).

## Outputs
- `Story[]` rows with `status: "discovered"`, each with `sources[]` and an
  optional `discovery_score`.
- A `DiscoveryRun` record summarizing the run (attempted/successful
  sources, candidates found, candidates after dedup, errors/warnings).

## Data models
- `Story` / `StoryDiscoveryInput` — `types/story.ts`
- `StorySource` — `types/story-source.ts`
- `DiscoveryRun` — `types/discovery-run.ts`
- `DiscoveryScore` / `DiscoveryScoreBreakdown` — `types/discovery-score.ts`
- `FitScoreRef` / `EvidenceConfidenceRef` — `types/downstream-refs.ts` (read-only, downstream-owned)

## Repository interface
`StoryDiscoveryRepository` (`repositories/story-discovery-repository.ts`).
No implementation yet — a future batch implements this against
`src/lib/db.ts`, the existing shared DB wrapper, rather than a second,
competing DB client. Deliberately has no method for writing `fit_score`
or `evidence_confidence`.

## Provider interface
`SearchProvider` (`providers/search-provider.ts`) — `searchStories`,
`searchByCategory`, `searchByRegion`, `searchRecent`. No concrete provider
(NewsAPI/GDELT/RSS) implemented yet; architecture supports multiple.

## Future API boundary
Per TECH SPEC Section 5: a single route, `POST /api/discovery/run`, will
trigger this module's logic and write results via
`StoryDiscoveryRepository`. Not built in this batch. `FindStoriesAction.tsx`
in Module 01 is where this call will be wired in.

## Future Module 03 handoff
Module 03 reads `Story` rows where `status: "discovered"`, computes the
authoritative Fit Score, and writes it via its own repository method
(not part of this interface) onto the same row — populating `Story.fit`
and `Story.priority`. Module 02's `discovery_score` is available to
Module 03 as one input signal among others, but Module 03 is free to
weight, ignore, or supersede it entirely; nothing in this contract
requires Module 03 to preserve it.

## Failure states
`DiscoveryRun.status`:
- `running` — in progress.
- `complete` — all attempted sources succeeded.
- `partial_failure` — some sources failed but at least one candidate was
  found; the Dashboard should surface this distinctly from `complete`.
- `failed` — no usable candidates produced.

## Dependencies
None new. TypeScript only — no schema/validation library added, consistent
with the existing project's dependency list (`next`, `react`, `tailwindcss`).
